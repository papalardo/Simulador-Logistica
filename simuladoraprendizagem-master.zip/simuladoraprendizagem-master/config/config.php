<?php

define('DB_HOST', 'localhost:3309');
define('DB_NAME', 'mydb');
define('DB_USER', 'root');
define('DB_PASS', '');
define('SYSTEM_STATUS', 'em_contrucao');
define('URL_BASE','http://192.168.0.11/my_simulador/');



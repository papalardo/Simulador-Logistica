<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Competencias</title>
	</head>
	<body>
		<form action="" method="post">
			<h2>Competencias Noreteadoras</h2>
			Informe a competencia:
			<input type="text" size="1px" name="nomecurso">	<br><br>
			<input type="submit" value="Próximo ítem">
		</form>
	</body>
</html>

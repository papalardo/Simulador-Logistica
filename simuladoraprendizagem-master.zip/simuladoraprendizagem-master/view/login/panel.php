
		<div class="col-md-9">
            <div class="profile-content">
			<?php
                echo $_SESSION['nome_usu'];
                echo $_SESSION['email_usu'];
                echo $_SESSION['sexo_usu'];
            ?>
            </div>
		</div>

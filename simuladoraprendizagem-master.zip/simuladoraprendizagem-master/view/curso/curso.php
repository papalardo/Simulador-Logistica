<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Simulador</title>
	</head>
	<body>
		<form action="" method="post">
			<h2>Curso</h2>
			Nome do Curso:
			<input type="text" name="nomecurso">

			<h3>Componente Curricular</h3>
			Nome do Componente Curricular:
			<input type="text" name="nomecompcur"> <br>
			Carga Horária:
			<input type="text" name="cargahoraria"> <br><br>
			<input type="submit" value="Salvar">
		</form>
	</body>
</html>

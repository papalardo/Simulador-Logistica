<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Realização do ciclo</title>
	</head>
	<body>
		<form action="" method="post">
			<h2>Resultado da Etapa</h2>
			Sua pontuação atingida foi:
			<input type="text" size="1px" name="nomecurso">	<br><br>
			<input type="submit" value="Finalizar módulo">
		</form>
	</body>
</html>

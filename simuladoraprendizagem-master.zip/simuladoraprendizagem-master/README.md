# simuladoraprendizagem
Simulador de Aprendizagem - Gama


# ..

> ..



